using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("• SumFor:");
        RunStrategy("SumFor", SumFor);

        Console.WriteLine("\n• SumIte:");
        RunStrategy("SumIte", SumIte);
    }

    // Método con fórmula matemática
    static int SumFor(int n) => n * (n + 1) / 2;

    // Método iterativo equivalente a la recursión
    static int SumIte(int n)
    {
        int sum = 0;
        for (int i = 1; i <= n; i++)
            sum += i;
        return sum;
    }

    // Estrategia: probar de 1 hasta Max (ascendente) y de Max hasta 1 (descendente)
    static void RunStrategy(string methodName, Func<int, int> sumMethod)
    {
        // Ascendente
        int lastValidN = 1, lastValidSum = 1;
        for (int n = 1; n <= int.MaxValue; n++)
        {
            int sum = sumMethod(n);
            if (sum > 0)
            {
                lastValidN = n;
                lastValidSum = sum;
            }
            else break;
        }
        Console.WriteLine($"\t◦ From 1 to Max → n: {lastValidN} → sum: {lastValidSum}");

        // Descendente
        int firstValidN = -1, firstValidSum = -1;
        for (int n = int.MaxValue; n >= 1; n--)
        {
            int sum = sumMethod(n);
            if (sum > 0)
            {
                firstValidN = n;
                firstValidSum = sum;
                break;
            }
        }
        Console.WriteLine($"\t◦ From Max to 1 → n: {firstValidN} → sum: {firstValidSum}");
    }
}
